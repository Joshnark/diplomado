#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

const int PORT = 8080;
const std::string SERVER_IP = "127.0.0.1";

// Servidor UDP ultra-rápido
void servidor_udp() {
    int sockfd;
    char buffer[1024];
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len = sizeof(cliaddr);
    
    // Crear socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);
    
    bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));
    
    std::cout << "Servidor UDP ultra-rápido escuchando..." << std::endl;
    
    while (true) {
        // Recibir mensaje
        int n = recvfrom(sockfd, buffer, sizeof(buffer), 0, 
                        (struct sockaddr *)&cliaddr, &len);
        
        if (n > 0) {
            // Preparar respuesta inline
            buffer[n] = '\0';
            std::string respuesta = "hola ";
            respuesta.append(buffer, n);
            
            // Enviar respuesta inmediatamente
            sendto(sockfd, respuesta.c_str(), respuesta.length(), 0,
                   (const struct sockaddr *)&cliaddr, len);
        }
    }
}

// Cliente UDP optimizado
void cliente_udp() {
    std::this_thread::sleep_for(std::chrono::milliseconds(50));
    
    int sockfd;
    char buffer[1024];
    struct sockaddr_in servaddr;
    socklen_t len = sizeof(servaddr);
    
    // Crear socket UDP
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP.c_str(), &servaddr.sin_addr);
    
    std::string input;
    while (true) {
        std::cout << "\nIngresa mensaje (o 'quit'): ";
        std::getline(std::cin, input);
        
        if (input == "quit") break;
        if (input.empty()) continue;
        
        // Medición de tiempo ultra-precisa
        auto inicio = std::chrono::high_resolution_clock::now();
        
        // Enviar
        sendto(sockfd, input.c_str(), input.length(), 0,
               (const struct sockaddr *)&servaddr, sizeof(servaddr));
        
        // Recibir
        int n = recvfrom(sockfd, buffer, sizeof(buffer), 0,
                        (struct sockaddr *)&servaddr, &len);
        
        auto fin = std::chrono::high_resolution_clock::now();
        
        auto duracion = std::chrono::duration_cast<std::chrono::nanoseconds>(fin - inicio);
        
        if (n > 0) {
            buffer[n] = '\0';
            std::cout << "Respuesta: " << buffer << std::endl;
            std::cout << "Tiempo: " << (duracion.count() / 1000.0) << " μs (" 
                      << (duracion.count() / 1000000.0) << " ms)" << std::endl;
        }
    }
    
    close(sockfd);
}

int main() {
    std::cout << "=== Socket UDP ULTRA-OPTIMIZADO ===" << std::endl;
    
    std::thread hilo_servidor(servidor_udp);
    cliente_udp();
    
    return 0;
}
