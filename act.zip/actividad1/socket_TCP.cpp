#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>

const int PORT = 8080;
const std::string SERVER_IP = "127.0.0.1";

// Función del servidor optimizada
void servidor() {
    int server_fd, client_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[1024];
    
    // Crear socket del servidor
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    
    // Optimizaciones del socket
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
    setsockopt(server_fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt)); // Deshabilitar algoritmo de Nagle
    
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    
    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 1);
    
    std::cout << "Servidor escuchando en puerto " << PORT << std::endl;
    
    // Aceptar UNA conexión y mantenerla
    client_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
    std::cout << "Cliente conectado. Listo para recibir mensajes..." << std::endl;
    
    while (true) {
        // Leer mensaje del cliente
        memset(buffer, 0, sizeof(buffer));
        int valread = recv(client_socket, buffer, sizeof(buffer), 0);
        
        if (valread <= 0) {
            std::cout << "Cliente desconectado" << std::endl;
            break;
        }
        
        // Procesar y responder inmediatamente
        std::string respuesta = "hola ";
        respuesta.append(buffer, valread);
        
        // Enviar respuesta inmediatamente
        send(client_socket, respuesta.c_str(), respuesta.length(), 0);
    }
    
    close(client_socket);
    close(server_fd);
}

// Cliente optimizado con conexión persistente
void cliente() {
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    
    int sock;
    struct sockaddr_in serv_addr;
    char buffer[1024];
    int opt = 1;
    
    // Crear socket una sola vez
    sock = socket(AF_INET, SOCK_STREAM, 0);
    
    // Optimizaciones del cliente
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP.c_str(), &serv_addr.sin_addr);
    
    // Conectar una sola vez
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Error de conexión" << std::endl;
        return;
    }
    
    std::cout << "Conectado al servidor. Listo para enviar mensajes." << std::endl;
    
    std::string input;
    while (true) {
        std::cout << "\nIngresa mensaje (o 'quit'): ";
        std::getline(std::cin, input);
        
        if (input == "quit") break;
        if (input.empty()) continue;
        
        // Medir tiempo con mayor precisión
        auto inicio = std::chrono::high_resolution_clock::now();
        
        // Enviar mensaje
        send(sock, input.c_str(), input.length(), 0);
        
        // Recibir respuesta
        memset(buffer, 0, sizeof(buffer));
        int valread = recv(sock, buffer, sizeof(buffer), 0);
        
        auto fin = std::chrono::high_resolution_clock::now();
        
        // Calcular en microsegundos
        auto duracion = std::chrono::duration_cast<std::chrono::microseconds>(fin - inicio);
        
        if (valread > 0) {
            buffer[valread] = '\0';
            std::cout << "Respuesta: " << buffer << std::endl;
            std::cout << "Tiempo: " << duracion.count() << " μs (" 
                      << (duracion.count() / 1000.0) << " ms)" << std::endl;
        }
    }
    
    close(sock);
}

int main() {
    std::cout << "=== Programa Socket TCP ===" << std::endl;
    
    std::thread hilo_servidor(servidor);
    cliente();
    
    return 0;
}
